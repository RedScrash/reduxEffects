import { UsuariosEffects } from './usuarios.effects';

export const EffectsArray: any[] = [UsuariosEffects];
